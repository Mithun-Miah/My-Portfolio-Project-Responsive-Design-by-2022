// text effect start
var typed = new Typed('.nameTitle',{
    strings: ["Hello...","I'M MITHUN MIAH"],
    typeSpeed:200,
    loop:false
});
var typed = new Typed('.positionTitle',{
    strings: ["Web Designer","Front-End Web Developer","Back-End Web Developer"],
    typeSpeed:100,
    loop:true
});
// text effect end

// progress bar code sample start

// progress bar code sample end